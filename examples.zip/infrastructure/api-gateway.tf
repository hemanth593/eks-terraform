# ===================================================================
# API Gateway
# ===================================================================
resource "aws_api_gateway_rest_api" "pipeline" {
  name        = "${local.prefix}-api"
  description = "Verizon EKS Cluster Lifecycle Pipeline API"

  endpoint_configuration {
    types = ["REGIONAL"]
  }

  tags = { Name = "${local.prefix}-api" }
}

# ===================================================================
# /clusters
# ===================================================================
resource "aws_api_gateway_resource" "clusters" {
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  parent_id   = aws_api_gateway_rest_api.pipeline.root_resource_id
  path_part   = "clusters"
}

resource "aws_api_gateway_method" "create_cluster" {
  rest_api_id   = aws_api_gateway_rest_api.pipeline.id
  resource_id   = aws_api_gateway_resource.clusters.id
  http_method   = "POST"
  authorization = "NONE"
}

resource "aws_api_gateway_integration" "create_cluster" {
  rest_api_id             = aws_api_gateway_rest_api.pipeline.id
  resource_id             = aws_api_gateway_resource.clusters.id
  http_method             = aws_api_gateway_method.create_cluster.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.trigger.invoke_arn
}

# ===================================================================
# /clusters/{job_id}
# ===================================================================
resource "aws_api_gateway_resource" "cluster_job" {
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  parent_id   = aws_api_gateway_resource.clusters.id
  path_part   = "{job_id}"
}

# ===================================================================
# /clusters/{job_id}/execute-stage
# ===================================================================
resource "aws_api_gateway_resource" "execute_stage" {
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  parent_id   = aws_api_gateway_resource.cluster_job.id
  path_part   = "execute-stage"
}

resource "aws_api_gateway_method" "execute_stage" {
  rest_api_id   = aws_api_gateway_rest_api.pipeline.id
  resource_id   = aws_api_gateway_resource.execute_stage.id
  http_method   = "POST"
  authorization = "NONE"

  request_parameters = {
    "method.request.path.job_id" = true
  }
}

resource "aws_api_gateway_integration" "execute_stage" {
  rest_api_id             = aws_api_gateway_rest_api.pipeline.id
  resource_id             = aws_api_gateway_resource.execute_stage.id
  http_method             = aws_api_gateway_method.execute_stage.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.execute_stage.invoke_arn
}

# ===================================================================
# /clusters/{job_id}/status
# ===================================================================
resource "aws_api_gateway_resource" "cluster_status" {
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  parent_id   = aws_api_gateway_resource.cluster_job.id
  path_part   = "status"
}

resource "aws_api_gateway_method" "get_status" {
  rest_api_id   = aws_api_gateway_rest_api.pipeline.id
  resource_id   = aws_api_gateway_resource.cluster_status.id
  http_method   = "GET"
  authorization = "NONE"

  request_parameters = {
    "method.request.path.job_id" = true
  }
}

resource "aws_api_gateway_integration" "get_status" {
  rest_api_id             = aws_api_gateway_rest_api.pipeline.id
  resource_id             = aws_api_gateway_resource.cluster_status.id
  http_method             = aws_api_gateway_method.get_status.http_method
  integration_http_method = "POST"
  type                    = "AWS_PROXY"
  uri                     = aws_lambda_function.status.invoke_arn
}

# ===================================================================
# CORS
# ===================================================================
module "cors_clusters" {
  source      = "./modules/cors"
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  resource_id = aws_api_gateway_resource.clusters.id
}

module "cors_execute_stage" {
  source      = "./modules/cors"
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  resource_id = aws_api_gateway_resource.execute_stage.id
}

module "cors_status" {
  source      = "./modules/cors"
  rest_api_id = aws_api_gateway_rest_api.pipeline.id
  resource_id = aws_api_gateway_resource.cluster_status.id
}

# ===================================================================
# Deployment & Stage
# ===================================================================
resource "aws_api_gateway_deployment" "pipeline" {
  rest_api_id = aws_api_gateway_rest_api.pipeline.id

  depends_on = [
    aws_api_gateway_integration.create_cluster,
    aws_api_gateway_integration.execute_stage,
    aws_api_gateway_integration.get_status,
  ]

  triggers = {
    redeployment = sha1(jsonencode([
      aws_api_gateway_resource.clusters,
      aws_api_gateway_resource.execute_stage,
      aws_api_gateway_resource.cluster_status,
      aws_api_gateway_method.create_cluster,
      aws_api_gateway_method.execute_stage,
      aws_api_gateway_method.get_status,
      aws_api_gateway_integration.create_cluster,
      aws_api_gateway_integration.execute_stage,
      aws_api_gateway_integration.get_status,
    ]))
  }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_api_gateway_stage" "pipeline" {
  deployment_id = aws_api_gateway_deployment.pipeline.id
  rest_api_id   = aws_api_gateway_rest_api.pipeline.id
  stage_name    = var.environment

  tags = { Name = "${local.prefix}-${var.environment}" }
}

# ===================================================================
# Lambda Permissions
# ===================================================================
resource "aws_lambda_permission" "apigw_trigger" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.trigger.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.pipeline.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_execute_stage" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.execute_stage.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.pipeline.execution_arn}/*/*"
}

resource "aws_lambda_permission" "apigw_status" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.status.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_api_gateway_rest_api.pipeline.execution_arn}/*/*"
}
