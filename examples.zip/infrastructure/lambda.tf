# ===================================================================
# Lambda Packaging
# ===================================================================
data "archive_file" "trigger" {
  type        = "zip"
  output_path = "${path.module}/.build/trigger.zip"

  source {
    content  = file("${path.module}/../lambdas/trigger/index.py")
    filename = "index.py"
  }
  source {
    content  = file("${path.module}/../lambdas/shared.py")
    filename = "shared.py"
  }
}

data "archive_file" "execute_stage" {
  type        = "zip"
  output_path = "${path.module}/.build/execute_stage.zip"

  source {
    content  = file("${path.module}/../lambdas/execute_stage/index.py")
    filename = "index.py"
  }
  source {
    content  = file("${path.module}/../lambdas/shared.py")
    filename = "shared.py"
  }
}

data "archive_file" "status" {
  type        = "zip"
  output_path = "${path.module}/.build/status.zip"

  source {
    content  = file("${path.module}/../lambdas/status/index.py")
    filename = "index.py"
  }
  source {
    content  = file("${path.module}/../lambdas/shared.py")
    filename = "shared.py"
  }
}

# ===================================================================
# Lambda Functions
# ===================================================================
resource "aws_lambda_function" "trigger" {
  function_name    = "${local.prefix}-trigger"
  role             = aws_iam_role.lambda.arn
  handler          = "index.handler"
  runtime          = var.lambda_runtime
  timeout          = 30
  memory_size      = 256
  filename         = data.archive_file.trigger.output_path
  source_code_hash = data.archive_file.trigger.output_base64sha256

  environment {
    variables = {
      S3_BUCKET = var.s3_bucket_name
    }
  }

  tags = { Name = "${local.prefix}-trigger" }
}

resource "aws_lambda_function" "execute_stage" {
  function_name    = "${local.prefix}-execute-stage"
  role             = aws_iam_role.lambda.arn
  handler          = "index.handler"
  runtime          = var.lambda_runtime
  timeout          = 30
  memory_size      = 256
  filename         = data.archive_file.execute_stage.output_path
  source_code_hash = data.archive_file.execute_stage.output_base64sha256

  environment {
    variables = {
      S3_BUCKET        = var.s3_bucket_name
      ANSIBLE_BASE_URL = var.ansible_base_url
    }
  }

  tags = { Name = "${local.prefix}-execute-stage" }
}

resource "aws_lambda_function" "status" {
  function_name    = "${local.prefix}-status"
  role             = aws_iam_role.lambda.arn
  handler          = "index.handler"
  runtime          = var.lambda_runtime
  timeout          = 30
  memory_size      = 256
  filename         = data.archive_file.status.output_path
  source_code_hash = data.archive_file.status.output_base64sha256

  environment {
    variables = {
      S3_BUCKET        = var.s3_bucket_name
      ANSIBLE_BASE_URL = var.ansible_base_url
    }
  }

  tags = { Name = "${local.prefix}-status" }
}

# ===================================================================
# CloudWatch Log Groups
# ===================================================================
resource "aws_cloudwatch_log_group" "lambda_trigger" {
  name              = "/aws/lambda/${aws_lambda_function.trigger.function_name}"
  retention_in_days = 14
}

resource "aws_cloudwatch_log_group" "lambda_execute_stage" {
  name              = "/aws/lambda/${aws_lambda_function.execute_stage.function_name}"
  retention_in_days = 14
}

resource "aws_cloudwatch_log_group" "lambda_status" {
  name              = "/aws/lambda/${aws_lambda_function.status.function_name}"
  retention_in_days = 14
}
