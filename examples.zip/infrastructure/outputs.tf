output "api_gateway_url" {
  description = "Base URL for the Verizon pipeline API"
  value       = aws_api_gateway_stage.pipeline.invoke_url
}

output "api_gateway_id" {
  description = "API Gateway REST API ID"
  value       = aws_api_gateway_rest_api.pipeline.id
}

output "s3_bucket_name" {
  description = "S3 bucket for pipeline metadata"
  value       = aws_s3_bucket.pipeline.bucket
}

output "lambda_arns" {
  description = "Lambda function ARNs"
  value = {
    trigger       = aws_lambda_function.trigger.arn
    execute_stage = aws_lambda_function.execute_stage.arn
    status        = aws_lambda_function.status.arn
  }
}

output "api_endpoints" {
  description = "API endpoint URLs"
  value = {
    create_cluster = "POST ${aws_api_gateway_stage.pipeline.invoke_url}/clusters"
    execute_stage  = "POST ${aws_api_gateway_stage.pipeline.invoke_url}/clusters/{job_id}/execute-stage"
    get_status     = "GET  ${aws_api_gateway_stage.pipeline.invoke_url}/clusters/{job_id}/status"
  }
}
