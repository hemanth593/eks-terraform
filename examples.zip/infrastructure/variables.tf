variable "project_name" {
  description = "Project name used for resource naming"
  type        = string
  default     = "verizon-eks-pipeline"
}

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment (dev, staging, prod)"
  type        = string
  default     = "dev"
}

variable "s3_bucket_name" {
  description = "S3 bucket name for pipeline metadata"
  type        = string
}

variable "ansible_base_url" {
  description = "Ansible+ platform base URL (e.g., https://ansibleplus.verizon.com/cloud)"
  type        = string
}

variable "lambda_runtime" {
  description = "Python runtime for Lambda functions"
  type        = string
  default     = "python3.12"
}

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}
