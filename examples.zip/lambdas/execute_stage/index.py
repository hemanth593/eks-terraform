"""POST /clusters/{job_id}/execute-stage - Forward a stage to Ansible+."""
import json
from shared import (
    get_env, get_s3_client, utcnow_iso,
    read_metadata, write_metadata, api_response,
    ansible_request, STAGE_NAMES, VALID_STAGES,
)

S3_BUCKET = get_env("S3_BUCKET")
ANSIBLE_BASE_URL = get_env("ANSIBLE_BASE_URL")

REQUIRED_FIELDS = [
    "stage", "cloud_name", "account_name", "region",
    "stack_name", "vsad", "ansible_payload",
]


def handler(event, context):
    job_id = event.get("pathParameters", {}).get("job_id")
    if not job_id:
        return api_response(400, {"error": "Missing job_id path parameter"})

    try:
        body = json.loads(event.get("body", "{}"))
    except (json.JSONDecodeError, TypeError):
        return api_response(400, {"error": "Invalid JSON body"})

    missing = [f for f in REQUIRED_FIELDS if f not in body]
    if missing:
        return api_response(400, {"error": f"Missing required fields: {missing}"})

    stage_num = body["stage"]
    if stage_num not in VALID_STAGES:
        return api_response(400, {
            "error": f"stage must be one of {sorted(VALID_STAGES)}"
        })

    s3 = get_s3_client()
    metadata = read_metadata(s3, S3_BUCKET, job_id)
    if not metadata:
        return api_response(404, {"error": f"Job {job_id} not found"})

    stage_name = STAGE_NAMES[stage_num]
    cloud_name = body["cloud_name"]
    account_name = body["account_name"]
    region = body["region"]
    stack_name = body["stack_name"]
    vsad = body["vsad"]
    ansible_payload = body["ansible_payload"]

    # Call Ansible+ API
    path = f"/app/tf/{cloud_name}/{account_name}/{region}/{stack_name}"
    query_params = {"vsad": vsad}

    try:
        result = ansible_request(
            ANSIBLE_BASE_URL, "POST", path,
            query_params=query_params, body=ansible_payload,
        )
    except RuntimeError as e:
        return api_response(502, {
            "error": f"Ansible+ API call failed: {str(e)}"
        })

    ansible_job_id = result.get("JobId")
    ansible_audit_id = result.get("AuditId")

    # Update stage metadata
    metadata["stages"][stage_name] = {
        "status": "running",
        "started_at": utcnow_iso(),
        "ansible_job_id": ansible_job_id,
        "ansible_audit_id": ansible_audit_id,
        "cloud_name": cloud_name,
        "account_name": account_name,
        "region": region,
        "stack_name": stack_name,
        "vsad": vsad,
    }
    metadata["status"] = "running"
    metadata["updated_at"] = utcnow_iso()
    write_metadata(s3, S3_BUCKET, job_id, metadata)

    return api_response(202, {
        "job_id": job_id,
        "stage": stage_name,
        "ansible_job_id": ansible_job_id,
        "ansible_audit_id": ansible_audit_id,
        "status": "RUNNING",
        "message": f"Stage {stage_num} ({stage_name}) submitted to Ansible+",
    })
