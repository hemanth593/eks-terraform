"""Shared utilities for Verizon EKS Lifecycle Pipeline Lambda functions."""
import json
import os
import boto3
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError


def get_env(key: str) -> str:
    """Get required environment variable."""
    value = os.environ.get(key)
    if not value:
        raise ValueError(f"Missing required environment variable: {key}")
    return value


def get_s3_client():
    return boto3.client("s3")


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def read_metadata(s3_client, bucket: str, job_id: str) -> dict:
    """Read metadata.json from S3."""
    key = f"inventory/{job_id}/metadata.json"
    try:
        resp = s3_client.get_object(Bucket=bucket, Key=key)
        return json.loads(resp["Body"].read().decode("utf-8"))
    except s3_client.exceptions.NoSuchKey:
        return None


def write_metadata(s3_client, bucket: str, job_id: str, metadata: dict):
    """Write metadata.json to S3."""
    key = f"inventory/{job_id}/metadata.json"
    s3_client.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(metadata, indent=2),
        ContentType="application/json",
    )


def api_response(status_code: int, body: dict) -> dict:
    """Format API Gateway response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
        },
        "body": json.dumps(body),
    }


STAGE_NAMES = {
    1: "01-eks-cluster",
    2: "02-node-group",
    3: "03-addons",
    4: "04-karpenter",
    5: "05-argocd",
}

VALID_STAGES = set(STAGE_NAMES.keys())


def ansible_request(base_url: str, method: str, path: str,
                    query_params: dict = None, body: dict = None) -> dict:
    """Make HTTP request to Ansible+ API."""
    url = f"{base_url}{path}"
    if query_params:
        url = f"{url}?{urlencode(query_params)}"

    data = json.dumps(body).encode("utf-8") if body else None
    headers = {"Content-Type": "application/json"} if body else {}

    req = Request(url, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except HTTPError as e:
        error_body = e.read().decode("utf-8") if e.fp else ""
        raise RuntimeError(
            f"Ansible+ API error {e.code}: {error_body}"
        ) from e
