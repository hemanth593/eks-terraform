"""GET /clusters/{job_id}/status - Return job metadata, proxy Ansible+ status."""
from shared import (
    get_env, get_s3_client, utcnow_iso,
    read_metadata, write_metadata, api_response,
    ansible_request,
)

S3_BUCKET = get_env("S3_BUCKET")
ANSIBLE_BASE_URL = get_env("ANSIBLE_BASE_URL")

STAGE_ORDER = [
    "01-eks-cluster", "02-node-group", "03-addons",
    "04-karpenter", "05-argocd",
]


def handler(event, context):
    job_id = event.get("pathParameters", {}).get("job_id")
    if not job_id:
        return api_response(400, {"error": "Missing job_id path parameter"})

    s3 = get_s3_client()
    metadata = read_metadata(s3, S3_BUCKET, job_id)
    if not metadata:
        return api_response(404, {"error": f"Job {job_id} not found"})

    # Check for any running stage and proxy Ansible+ status
    updated = False
    for stage_name in STAGE_ORDER:
        stage = metadata.get("stages", {}).get(stage_name, {})
        if stage.get("status") != "running":
            continue

        ansible_job_id = stage.get("ansible_job_id")
        if not ansible_job_id:
            continue

        cloud_name = stage.get("cloud_name", "")
        account_name = stage.get("account_name", "")
        vsad = stage.get("vsad", "")

        path = f"/app/tf/{cloud_name}/{account_name}/jobs/{ansible_job_id}"
        query_params = {"vsad": vsad} if vsad else None

        try:
            result = ansible_request(
                ANSIBLE_BASE_URL, "GET", path,
                query_params=query_params,
            )
        except RuntimeError:
            continue

        job_status = result.get("job_status", "").upper()

        if job_status == "SUCCEEDED":
            stage["status"] = "complete"
            stage["completed_at"] = utcnow_iso()
            stage["outputs"] = result.get("outputs", {})
            stage["resources"] = result.get("resources", [])
            updated = True
        elif job_status == "FAILED":
            stage["status"] = "failed"
            stage["failed_at"] = utcnow_iso()
            stage["error"] = result.get("job_status", "FAILED")
            stage["outputs"] = result.get("outputs", {})
            stage["resources"] = result.get("resources", [])
            updated = True

        metadata["stages"][stage_name] = stage

    if updated:
        all_complete = all(
            metadata["stages"].get(s, {}).get("status") == "complete"
            for s in STAGE_ORDER
        )
        any_failed = any(
            metadata["stages"].get(s, {}).get("status") == "failed"
            for s in STAGE_ORDER
        )
        if all_complete:
            metadata["status"] = "complete"
        elif any_failed:
            metadata["status"] = "failed"

        metadata["updated_at"] = utcnow_iso()
        write_metadata(s3, S3_BUCKET, job_id, metadata)

    return api_response(200, metadata)
