"""POST /clusters - Initialize a new cluster job."""
import json
from shared import get_env, get_s3_client, utcnow_iso, write_metadata, api_response

S3_BUCKET = get_env("S3_BUCKET")

REQUIRED_FIELDS = ["job_id", "cluster_name", "owner_id"]


def handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
    except (json.JSONDecodeError, TypeError):
        return api_response(400, {"error": "Invalid JSON body"})

    missing = [f for f in REQUIRED_FIELDS if f not in body]
    if missing:
        return api_response(400, {"error": f"Missing required fields: {missing}"})

    job_id = body["job_id"]
    s3 = get_s3_client()

    metadata = {
        "job_id": job_id,
        "cluster_name": body["cluster_name"],
        "owner_id": body["owner_id"],
        "status": "initialized",
        "created_at": utcnow_iso(),
        "updated_at": utcnow_iso(),
        "stages": {
            "01-eks-cluster": {"status": "pending"},
            "02-node-group": {"status": "pending"},
            "03-addons": {"status": "pending"},
            "04-karpenter": {"status": "pending"},
            "05-argocd": {"status": "pending"},
        },
    }

    write_metadata(s3, S3_BUCKET, job_id, metadata)

    return api_response(201, {
        "job_id": job_id,
        "status": "initialized",
        "message": "Job created. Use execute-stage to run each stage.",
    })
