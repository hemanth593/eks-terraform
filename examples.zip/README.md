# Verizon EKS Lifecycle Pipeline

EKS cluster provisioning through AWS API Gateway, Lambda, and Verizon's Ansible+ platform. Each pipeline stage is triggered manually by the UI and executed by Ansible+ (Terraform via Jenkins).

## Architecture

```
UI → API Gateway → Lambda → HTTP POST → ansibleplus.verizon.com (Terraform)
                                              ↓
UI → API Gateway → Lambda ← HTTP GET ← ansibleplus.verizon.com/jobs/{id}
                      ↓
                 S3 (metadata)
```

## Pipeline Stages

| Stage | Name | Description |
|-------|------|-------------|
| 1 | `01-eks-cluster` | EKS control plane |
| 2 | `02-node-group` | Managed node group |
| 3 | `03-addons` | EKS add-ons |
| 4 | `04-karpenter` | Karpenter autoscaler |
| 5 | `05-argocd` | ArgoCD via Helm |

Each stage is triggered individually by the UI. The Terraform code, git repo, branch, and path are fully configurable per stage call.

## Deployment

### 1. Deploy infrastructure

```bash
cd verizon/infrastructure

terraform init
terraform apply \
  -var='s3_bucket_name=verizon-eks-pipeline-metadata' \
  -var='ansible_base_url=https://ansibleplus.verizon.com/cloud'
```

Or use a tfvars file:

```bash
cat > terraform.tfvars <<EOF
s3_bucket_name   = "verizon-eks-pipeline-metadata"
ansible_base_url = "https://ansibleplus.verizon.com/cloud"
environment      = "dev"
EOF

terraform init
terraform apply
```

### 2. Get the API URL

```bash
API_URL=$(terraform output -raw api_gateway_url)
echo $API_URL
```

## Usage

### Step 1: Initialize a cluster job

```bash
curl -X POST "$API_URL/clusters" \
  -H "Content-Type: application/json" \
  -d @verizon/examples/payloads/create-cluster.json
```

Response:
```json
{
  "job_id": "job-prod-east-001",
  "status": "initialized",
  "message": "Job created. Use execute-stage to run each stage."
}
```

### Step 2: Execute each stage (UI-driven)

```bash
# Stage 1: EKS Cluster
curl -X POST "$API_URL/clusters/job-prod-east-001/execute-stage" \
  -H "Content-Type: application/json" \
  -d @verizon/examples/payloads/stage-01-eks-cluster.json
```

Response:
```json
{
  "job_id": "job-prod-east-001",
  "stage": "01-eks-cluster",
  "ansible_job_id": 858,
  "ansible_audit_id": 49794918,
  "status": "RUNNING",
  "message": "Stage 1 (01-eks-cluster) submitted to Ansible+"
}
```

Repeat for stages 2-5 after each previous stage completes.

### Step 3: Poll status

```bash
curl "$API_URL/clusters/job-prod-east-001/status"
```

The status endpoint proxies the Ansible+ job status API. When Ansible+ reports a stage as SUCCEEDED or FAILED, our metadata is updated automatically on the next poll.

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/clusters` | Initialize a new cluster job |
| POST | `/clusters/{job_id}/execute-stage` | Submit a stage to Ansible+ |
| GET | `/clusters/{job_id}/status` | Get job metadata (proxies Ansible+ status) |

## Execute-Stage Payload

Every `execute-stage` call requires these fields:

| Field | Type | Description |
|-------|------|-------------|
| `stage` | int | Stage number (1-5) |
| `cloud_name` | string | Cloud provider (e.g., `aws`) |
| `account_name` | string | Verizon account name |
| `region` | string | AWS region |
| `stack_name` | string | Ansible+ stack name |
| `vsad` | string | VSAD identifier |
| `ansible_payload` | object | Full Ansible+ request body (see below) |

### ansible_payload fields

| Field | Description |
|-------|-------------|
| `GitRepoUrl` | Terraform git repository URL |
| `GitBranch` | Git branch to use |
| `TemplDir` | Path to Terraform module in the repo |
| `OwnerId` | Owner identifier |
| `StackAction` | `CreateOrUpdate` or `Destroy` |
| `StackProtection` | `On` or `Off` |
| `TfVersion` | Terraform version (e.g., `Terraform_1.5.x`) |
| `TfRefresh` | Whether to refresh state |
| `TfDynamicParams` | Dynamic Terraform parameters |
| `TfVarsFile` | Terraform vars file name |
| `PlanOnly` | If true, only run `terraform plan` |
| `clientContext` | Optional client context (e.g., Jenkins callback URL) |

## Payload Examples

See `examples/payloads/` for complete request examples:
- `create-cluster.json` — Job initialization
- `stage-01-eks-cluster.json` — EKS cluster stage
- `stage-02-node-group.json` — Node group stage
- `stage-03-addons.json` — Add-ons stage
- `stage-04-karpenter.json` — Karpenter stage
- `stage-05-argocd.json` — ArgoCD stage

## Differences from Main Pipeline

| Aspect | Main Pipeline | Verizon Variant |
|--------|--------------|-----------------|
| Execution | ECS Fargate (direct Terraform) | Ansible+ (HTTP API) |
| Orchestration | Step Functions (automatic) | UI-driven (manual per stage) |
| Stage trigger | Automatic sequencing | `POST /execute-stage` per stage |
| Status | Lambda reads S3 + SFN | Lambda reads S3 + proxies Ansible+ |
| Infrastructure | API GW, Lambda, SFN, ECS, ECR, S3 | API GW, Lambda, S3 |
| Docker | Required (Terraform executor image) | Not needed |
